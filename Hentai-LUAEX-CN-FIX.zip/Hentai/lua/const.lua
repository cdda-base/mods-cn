--[[定数]]--


--[[文字のハイライト色パターン]]--
H_COLOR = {
	BLACK		= "black",
	WHITE		= "white",
	LIGHT_GRAY	= "light_gray",
	DARK_GRAY	= "dark_gray",
	RED			= "red",
	GREEN		= "green",
	BLUE		= "blue",
	CYAN		= "cyan",
	MAGENTA		= "magenta",
	BROWN		= "brown",
	LIGHT_RED	= "light_red",
	LIGHT_GREEN	= "light_green",
	LIGHT_BLUE	= "light_blue",
	LIGHT_CYAN	= "light_cyan",
	PINK		= "pink",
	YELLOW		= "yellow"
}

--[[*気持ちいいこと*中に表示されるテキスト]]--
MOVINGDOING_TEXTS = {
	"*啪咕啪克*",--Pakopako
	"\"哈,哈,哈♥\"",--Haa, haa♥
	"*好舒服*",--*Ki ku~u*
	"\"嗯,嗯,嗯♪\"",--La di da♪
	"\"呼,呼,呼♪\"",--Ufufu♪
	"\"啊,啊,啊♪\""--WooHoo♪
}
--todo: perhaps move these dialog lines out of const into json so we could randomize words and add gender-specific and etc checks?
--another problem is that you can still hear this even when deaf
--[[レイダー的な敵キャラ会話のテキスト]]--
VULGAR_SPEECH_TEXTS = {
	--ターゲットを発見した時
	TARGET_ACQUIRE = {
		--[[露骨なパロディネタはいちおう自粛。
			"\"地獄だ、やあ！\"",
		]]--
		"\"呸!\"",
		"\"啊哈！！！\"",
		"\"我会抓住你的！\"",
		"\"什--？！\"",
		"\"嘿，是敌人！\"",
		"\"我们真是有缘!\"",
		"\"敌人!\"",
		"\"哈！我看到你了！\"",
		"\"啊哈哈！\"",
		"\"我会把你的头扭断并做成玩具！\"",
		"\"啊哈哈！新鲜的玩具啊！\"",
		"\"啊哈哈！新鲜的肉啊！\"",
		"\"我们今天要开人肉宴！\"",
		"\"现在是强暴时间!\"",
		"(充满疯狂的笑声)",
		"\"该死!\"",
		"\"见鬼去吧！\""
		--"\"地獄だ、イェア！\""
	},
	--ターゲットと交戦中
	TARGET_ENGAGE = {
		--[[露骨なパロディネタはいちおう自粛。
			"\"殺しは初めてじゃないんだよ、新米！\"",
			"\"何百回とやってきた！そうすれば変わるだろう！？\"",
			"\"自分を制して、悪に徹しろ！\"",
		]]--
		"\"啊哈哈！\"",
		"\"害怕吗？！\"",
		"\"过来啊！\"",
		"\"血啊！血啊！血啊啊！！！\"",
		"\"给我见血吧！\"",
		"\"你就是个垃圾！\"",
		"\"你对我一无所知！\"",
		"\"先奸后杀？还是先杀后奸？...无论是哪个都感觉很爽啊！\"",
		"\"我要把你先奸后杀，再后奸！\"",
		"\"谋杀，死亡，杀戮！！\"",
		"\"我不介意帮助你出去，你知道吗？...不过是在和你做完之后！\"",
		"(充满疯狂的笑声)",
		"(怒吼)",
		"(嚎叫)",
		"(低声吼叫)",
		"\"死-----吧！！\"",
		"\"我要操你！\"",
		"\"我只是想和你玩玩，你不会介意的，对吧？！\"",
		"\"你这个小混蛋...\"",
		"\"为什么你还没死？！\"",
		"\"为什么你不能去死？！\"",
		"\"这不是我第一次杀人了，菜鸡！\"",
		"\"如果不能作为人类活下去了话，就只能作为恶魔活下去了啊！\"",
		"\"当你下地狱的时候，告诉他们是我送你来的！\"",
		"\"当我杀了你之后，我还要奸你的尸！不要担心，我会很温柔的！\"",
		"\"你会他妈的后悔的！\""
	},
	--ターゲットを見失った時
	TARGET_LOST = {
		"(咂嘴的声音)",
		"\"那家伙跑得真快...\"",
		"\"那个sb跑得太快了，草！\"",
		"\"出来吧，出来吧，你在哪呢！我马上杀了你！\"",
		"\"别躲着给我滚出来！\"",
		"\"小心，那个家伙还躲在附近\"",
		"\"别跑！\"",
		"\"该死的，tmd跑哪去了？！\"",
		"\"我看到你了！没有... 我看到了！没有... 草!\"",
		--"\"Chicken, chicken, chicken... Chicken!\""
	}
}

--[[profession"一人と一匹"スタート時のペット選択リストまとめ]]--
PROF_PET_LIST = {
	TITLE = "你的宠物是...",
	LIST_ITEM = {
		{
			ENTRY = "一只狗！",
			PET_ID = "mon_dog",
			BONUS_ITEM = {"pet_carrier", "dog_whistle"}
		},
		{
			ENTRY = "一只猫！",
			PET_ID = "mon_cat",
			BONUS_ITEM = {"pet_carrier", "can_tuna"}
		},
		{
			ENTRY = "一只熊！",
			PET_ID = "mon_bear_cub",
			BONUS_ITEM = {}
		},
		{
			ENTRY = "一只魅魔！",
			PET_ID = "mon_succubi",
			BONUS_ITEM = {"holy_choker"}
		}
	}
}

--[[アークCUBIのmonster_idリスト。主に上位敵の召喚用に使う。]]--
MON_ARCH_CUBI_LIST = {
	"mon_succubi_sadist",
	"mon_succubi_somnophilia",
	"mon_succubi_exhibitionism",
	"mon_succubi_lactophilia",
	"mon_incubi_sthenolagnia",
	"mon_incubi_phalloplas",
	"mon_incubi_hoplophilia"
}


SEX_MORALE_TYPE		= morale_type("morale_sex_good")	--*気持ちいいこと*の意欲タイプ
-- changed these to scale with the new time duration
SEX_BASE_TURN		= 600		--行為1wait当たりに掛かる基準ターン数(1ターン = 約6秒)。100=10分。
SEX_MIN_TURN		= 10		
SEX_MAX_TURN		= 3600		--行為全体に掛かる最大ターン数。1800=3時間。
SEX_FUN_DURATION	= 1200		--行為による意欲がどの程度長続きするかのtime_duration。
SEX_FUN_DECAY_START	= 300		--行為による意欲が冷め始めるまでのtime_duration。

D_GOM_BREAK_CHANCE	= 50		--あぶない方の避妊具が使用時に破損する確率(%)。

PREG_CHANCE = 10				--基礎妊娠確立(%)。
DEFAULT_PREG_SPEED_RATIO = 1	--孕んだ子供の成長スピード比率。


DEFAULT_NPC_NAME = "Tom"		--NPC新規生成時のデフォルト名。みんな大好きトム。


EFF_SPELL_CHARGE_INT_FACTOR = 30	--モンスター攻撃の魔法詠唱にかかるint_dur_factor。


--[[set_valueの値設定に使う名称]]--
EVENT_GOATHEAD_DEMON = "event_goathead_demon"				--モンスター"mon_goathead_demon"との会話イベントを発生させたかどうか
EVENT_DEMONBEING_SCHOOLGIRL = "event_demonbeing_schoolgirl"	--npc"demonbeing_schoolgirl"を発生させたかどうか
CREAMPIE_SEED_TYPE = "creampie_seed_type"					--注がれた種の種族を保持する。あなたがパパになるんですよ？
